/*
  Aquí está todo el contenido personal de la página. Si quieres cambiar nombres,
  fechas, textos o canciones, puedes hacerlo desde este pequeño bloque sin tocar
  la estructura del HTML.
*/
const siteContent = {
  letters: [
    {
      number: "01 / 03",
      label: "cuando empezamos",
      date: "sin fecha · pero me acuerdo",
      title: "Para Nachitos · desde el principio",
      paragraphs: [
        "Todavía no sé en qué momento dejaste de ser alguien más y te convertiste en una persona a la que siempre quería volver.",
        "Tal vez fue una conversación cualquiera. De esas que parecen normales, pero que con el tiempo terminan significando muchísimo. Desde entonces, ese día se me quedó guardado.",
      ],
    },
    {
      number: "02 / 03",
      label: "lo que me gusta de ti",
      date: "Para Nachitos · para un día malo",
      title: "Me gustas por tantas cosas",
      paragraphs: [
        "Me gusta que contigo cualquier día normal puede terminar siendo un buen día. No necesitas hacer mucho para que todo se sienta diferente.",
        "Me gusta tu risa, tus ocurrencias y la forma en que eres. Pero lo que más me gusta es poder ser yo cuando estoy contigo.",
      ],
    },
    {
      number: "03 / 03",
      label: "lo que viene",
      date: "Para Nachitos · para abrir algún día",
      title: "Todavía nos falta mucho",
      paragraphs: [
        "Quiero seguir juntando momentos contigo: canciones, mensajes a cualquier hora y días que terminan haciéndonos sonreír.",
        "No sé qué vaya a pasar después, pero tampoco necesito tenerlo todo claro. Si es contigo, me parece bien.",
      ],
    },
  ],
  photos: [
    {
      src: "uploads/Screenshot_20250916_145136_Roblox.jpg",
      caption: "nuestro primer lugar",
      date: "16 · 09 · 25",
      alt: "Un recuerdo de los dos en un mundo virtual",
    },
    {
      src: "uploads/Screenshot_20250923_153711_Roblox.jpg",
      caption: "una tarde normal",
      date: "23 · 09 · 25",
      alt: "Dos personajes juntos en un paisaje de colores",
    },
    {
      src: "uploads/Screenshot_20250930_223846_Roblox.jpg",
      caption: "aquí estábamos juntos",
      date: "30 · 09 · 25",
      alt: "Un momento especial de los dos",
    },
    {
      src: "uploads/Screenshot_20251010_211915_Roblox.jpg",
      caption: "qué bueno coincidir contigo",
      date: "10 · 10 · 25",
      alt: "Un recuerdo de un día juntos",
    },
    {
      src: "uploads/Screenshot_20251011_221232_Minecraft.jpg",
      caption: "haciendo nuestro mundo",
      date: "11 · 10 · 25",
      alt: "Una escena que construimos juntos",
    },
    {
      src: "uploads/Screenshot_20251014_225354_Roblox.jpg",
      caption: "solo tú y yo",
      date: "14 · 10 · 25",
      alt: "Dos personajes compartiendo un momento juntos",
    },
  ],
  timeline: [
    {
      date: "16 septiembre, 2025",
      title: "Cuando todo empezó",
      description: "Ese día no sabíamos que estábamos empezando a guardar recuerdos que después querríamos repetir.",
      photo: "uploads/Screenshot_20250916_145136_Roblox.jpg",
    },
    {
      date: "11 octubre, 2025",
      title: "Nuestro mundo",
      description: "Entre bloques, mensajes y planes que quizá nunca hicimos, terminamos armando un lugar solo para nosotros.",
      photo: "uploads/Screenshot_20251011_221232_Minecraft.jpg",
    },
    {
      date: "08 febrero, 2026",
      title: "Un momento tranquilo",
      description: "No necesitábamos nada más: estar juntos, una habitación tranquila y la noche afuera.",
      photo: "uploads/Screenshot_20260208_235544_Heartopia.jpg",
    },
  ],
  playlist: {
    tracks: [
      {
        title: "Es que yo te quiero a ti",
        artist: "Kevin Kaarl",
        id: "6noNXh0HLbx1zWPMuhiAPt",
        url: "https://open.spotify.com/intl-es/track/6noNXh0HLbx1zWPMuhiAPt",
      },
      {
        title: "Te amo y más",
        artist: "Diego Luna, Gustavo Santaolalla",
        id: "5I0aHj2JSQpoxSQnh3XcjO",
        url: "https://open.spotify.com/intl-es/track/5I0aHj2JSQpoxSQnh3XcjO",
      },
      {
        title: "Quédate esta noche",
        artist: "Mon Laferte",
        id: "14kf1Cdj0sdtKtMY02IBcB",
        url: "https://open.spotify.com/intl-es/track/14kf1Cdj0sdtKtMY02IBcB",
      },
      {
        title: "Hasta la muerte",
        artist: "Eslabon Armado, Iván Cornejo",
        id: "3qAJAUr7yc9bPDx4ESt6ND",
        url: "https://open.spotify.com/intl-es/track/3qAJAUr7yc9bPDx4ESt6ND",
      },
      {
        title: "Just the Way You Are",
        artist: "Bruno Mars",
        id: "7BqBn9nzAq8spo5e7cZ0dJ",
        url: "https://open.spotify.com/intl-es/track/7BqBn9nzAq8spo5e7cZ0dJ",
      },
    ],
  },
};

const $ = (selector, parent = document) => parent.querySelector(selector);
const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];

function renderLetters() {
  const grid = $("#letters-grid");
  grid.innerHTML = siteContent.letters
    .map(
      (letter, index) => `
        <button class="letter-card reveal ${index === 1 ? "reveal-delay-1" : index === 2 ? "reveal-delay-2" : ""}" type="button" data-letter-index="${index}" aria-label="Abrir carta: ${letter.label}">
          <span class="letter-card-inner">
            <span class="envelope">
              <span class="envelope-flap"></span>
              <span class="envelope-number">${letter.number}</span>
              <span class="envelope-stamp">♡</span>
              <span class="envelope-letter-mark">✉</span>
              <span class="envelope-label">${letter.label}</span>
              <span class="envelope-cta">abrir carta ↗</span>
            </span>
          </span>
        </button>
      `,
    )
    .join("");
}

function renderPhotos() {
  const grid = $("#polaroid-grid");
  grid.innerHTML = siteContent.photos
    .map(
      (photo, index) => `
        <button class="polaroid-card reveal ${index % 3 === 1 ? "reveal-delay-1" : ""}" type="button" data-photo-index="${index}" aria-label="Ver foto: ${photo.caption}">
          <span class="polaroid-pin" aria-hidden="true"></span>
          <img class="polaroid-image" src="${photo.src}" alt="${photo.alt}" loading="lazy" />
          <span class="polaroid-caption">${photo.caption}</span>
          <span class="polaroid-date">${photo.date}</span>
        </button>
      `,
    )
    .join("");
}

function renderTimeline() {
  $("#timeline").innerHTML = siteContent.timeline
    .map(
      (item, index) => `
        <article class="timeline-item reveal ${index ? "reveal-delay-1" : ""}">
          <span class="timeline-dot" aria-hidden="true"></span>
          <div class="timeline-content">
            <div class="timeline-date">${item.date}</div>
            <h3 class="timeline-title">${item.title}</h3>
            <p class="timeline-description">${item.description}</p>
            <img class="timeline-photo" src="${item.photo}" alt="" loading="lazy" />
          </div>
        </article>
      `,
    )
    .join("");
}

function openLetter(index) {
  const letter = siteContent.letters[index];
  $("#modal-letter-date").textContent = letter.date;
  $("#modal-letter-title").textContent = letter.title;
  $("#modal-letter-body").innerHTML = letter.paragraphs.map((paragraph) => `<p>${paragraph}</p>`).join("");
  $("#letter-modal").classList.add("is-open");
  $("#letter-modal").setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-open");
  $(".modal-close", $("#letter-modal")).focus();
}

function closeModal(modal) {
  modal.classList.remove("is-open");
  modal.setAttribute("aria-hidden", "true");
  if (!$(".photo-modal.is-open") && !$(".letter-modal.is-open")) document.body.classList.remove("modal-open");
}

function openPhoto(index) {
  const photo = siteContent.photos[index];
  const image = $("#modal-photo");
  image.src = photo.src;
  image.alt = photo.alt;
  $("#modal-photo-caption").textContent = photo.caption;
  $("#modal-photo-date").textContent = photo.date;
  $("#photo-modal").classList.add("is-open");
  $("#photo-modal").setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-open");
  $(".modal-close", $("#photo-modal")).focus();
}

function setupReveal() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 },
  );
  $$(".reveal").forEach((element) => observer.observe(element));
}

function setupLettersAndPhotos() {
  $("#letters-grid").addEventListener("click", (event) => {
    const card = event.target.closest("[data-letter-index]");
    if (card) openLetter(Number(card.dataset.letterIndex));
  });
  $("#polaroid-grid").addEventListener("click", (event) => {
    const card = event.target.closest("[data-photo-index]");
    if (card) openPhoto(Number(card.dataset.photoIndex));
  });
  $$("[data-close-modal]").forEach((button) => button.addEventListener("click", () => closeModal($("#letter-modal"))));
  $$("[data-close-photo]").forEach((button) => button.addEventListener("click", () => closeModal($("#photo-modal"))));
  document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    if ($("#letter-modal").classList.contains("is-open")) closeModal($("#letter-modal"));
    if ($("#photo-modal").classList.contains("is-open")) closeModal($("#photo-modal"));
  });
}

function setupFinalLetter() {
  const envelope = $("#final-envelope");
  const letter = $("#final-letter");
  envelope.addEventListener("click", () => {
    const isOpen = envelope.getAttribute("aria-expanded") === "true";
    envelope.setAttribute("aria-expanded", String(!isOpen));
    letter.classList.toggle("is-visible", !isOpen);
    letter.setAttribute("aria-hidden", String(isOpen));
  });
}

function setupPlaylist() {
  const tracks = siteContent.playlist.tracks;
  const trackList = $("#track-list");
  const embed = $("#spotify-embed");

  trackList.innerHTML = tracks
    .map(
      (track, index) => `
        <button class="track-item${index === 0 ? " is-active" : ""}" type="button" data-track-index="${index}">
          <span class="track-item-number">${String(index + 1).padStart(2, "0")}</span>
          <span class="track-item-copy">
            <strong>${track.title}</strong>
            <small>${track.artist}</small>
          </span>
          <span class="track-item-play" aria-hidden="true">▶</span>
        </button>
      `,
    )
    .join("");

  const selectTrack = (index) => {
    const track = tracks[index];
    embed.src = `https://open.spotify.com/embed/track/${track.id}?utm_source=generator&theme=0`;
    $$(".track-item", trackList).forEach((item, itemIndex) => {
      item.classList.toggle("is-active", itemIndex === index);
    });
  };

  trackList.addEventListener("click", (event) => {
    const button = event.target.closest("[data-track-index]");
    if (button) selectTrack(Number(button.dataset.trackIndex));
  });
}

function setupParallax() {
  const photo = $(".hero-photo-wrap");
  if (!photo || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  let ticking = false;
  window.addEventListener(
    "scroll",
    () => {
      if (ticking) return;
      window.requestAnimationFrame(() => {
        const offset = Math.min(window.scrollY * 0.035, 18);
        photo.style.translate = `0 ${offset}px`;
        ticking = false;
      });
      ticking = true;
    },
    { passive: true },
  );
}

function setupSakura() {
  const petalField = $("#falling-petals");
  if (!petalField) return;
  const petals = Array.from({ length: 30 }, (_, index) => {
    const petal = document.createElement("span");
    petal.className = "sakura-petal";
    petal.style.left = `${(index * 31 + 7) % 103 - 2}%`;
    petal.style.setProperty("--fall-duration", `${10 + (index % 6) * 1.5}s`);
    petal.style.setProperty("--fall-delay", `${-((index * 1.7) % 13)}s`);
    petal.style.setProperty("--sway", `${index % 2 ? 1 : -1}`);
    petal.style.setProperty("--petal-scale", `${0.62 + (index % 5) * 0.1}`);
    petalField.appendChild(petal);
  });
}

renderLetters();
renderPhotos();
renderTimeline();
setupReveal();
setupLettersAndPhotos();
setupFinalLetter();
setupPlaylist();
setupParallax();
setupSakura();
